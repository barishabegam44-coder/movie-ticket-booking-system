<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $movie_name = $_POST['movie_name'];
    $showtime = $_POST['showtime'];

    $sql = "INSERT INTO movies (movie_name, showtime) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $movie_name, $showtime);

    if ($stmt->execute()) {
        echo "<script>alert('🎬 Movie Added'); window.location.href='admin_panel.php';</script>";
    } else {
        echo "<script>alert('❌ Failed to add movie'); window.location.href='admin_panel.php';</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
