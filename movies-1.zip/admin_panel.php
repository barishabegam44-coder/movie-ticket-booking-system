﻿<?php
session_start();
include 'db.php';

if (!isset($_SESSION['admin'])) {
    header("Location: admin.html");
    exit();
}

// Add Movie
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
    $title = trim($_POST['title']);
    $time = $_POST['show_time'];
    $date = $_POST['date'];
    $seats = $_POST['available_seats'];

    $stmt = $conn->prepare("INSERT INTO movies (title, show_time, date, available_seats) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sssi", $title, $time, $date, $seats);

    if ($stmt->execute()) {
        echo "<script>alert('🎬 Movie Added'); window.location.href='admin_panel.php';</script>";
        exit();
    } else {
        echo "<script>alert('Error adding movie: " . $stmt->error . "');</script>";
    }
}

// Delete Movie
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    if ($conn->query("DELETE FROM movies WHERE id = $id")) {
        echo "<script>alert('🗑️ Movie deleted'); window.location.href='admin_panel.php';</script>";
        exit();
    }
}

// Fetch Movies
$movies = $conn->query("SELECT * FROM movies ORDER BY date, show_time");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🎬 Admin Panel - Movie Manager</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap');
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #d1c4e9, #b39ddb, #9575cd); /* Purple gradient */
            color: #000; /* Black text */
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            background-color: #fff;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
            max-width: 900px;
            width: 100%;
            margin: 20px;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #eee;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        h1, h3 {
            color: #000; /* Black headings */
            margin: 0;
        }
        .logout-btn {
            background-color: #8e24aa; /* Purple */
            color: white;
            padding: 8px 16px;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }
        .logout-btn:hover {
            background-color: #6a1b9a;
        }
        .form-container {
            background-color: #f3e5f5; /* Light purple background */
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            font-weight: 600;
            margin-bottom: 5px;
            color: #000; /* Black labels */
        }
        input[type="text"], input[type="time"], input[type="date"], input[type="number"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #aaa;
            border-radius: 6px;
            box-sizing: border-box;
            font-size: 14px;
        }
        button {
            background-color: #7e57c2; /* Purple button */
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #5e35b1;
        }
        .movie-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .movie-table th, .movie-table td {
            border: 1px solid #e0e0e0;
            padding: 12px;
            text-align: left;
            color: #000; /* Black text inside table */
        }
        .movie-table th {
            background-color: #ede7f6; /* Light purple header */
            color: #000;
            font-weight: 600;
        }
        .movie-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .movie-table tr:hover {
            background-color: #f1f1f1;
        }
        .delete-btn {
            color: #c62828;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s ease;
        }
        .delete-btn:hover {
            color: #8e0000;
        }
        .back-btn-container {
            margin-top: 30px;
            text-align: center;
        }
        .back-btn {
            background-color: #6a1b9a;
            color: white;
            padding: 12px 24px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }
        .back-btn:hover {
            background-color: #4a148c;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <h1>🎬 Admin Panel: Manage Movies</h1>
        <a href="logout.php" class="logout-btn">🚪 Logout</a>
    </div>

    <div class="form-container">
        <h3>➕ Add a New Movie</h3>
        <form method="post">
            <div class="form-group">
                <label for="title">Title:</label>
                <input type="text" name="title" required>
            </div>
            <div class="form-group">
                <label for="show_time">Show Time:</label>
                <input type="time" name="show_time" required>
            </div>
            <div class="form-group">
                <label for="date">Date:</label>
                <input type="date" name="date" required>
            </div>
            <div class="form-group">
                <label for="available_seats">Available Seats:</label>
                <input type="number" name="available_seats" required>
            </div>
            <button type="submit" name="add">✨ Add Movie</button>
        </form>
    </div>

    <h3>🍿 Current Movies</h3>
    <table class="movie-table">
        <thead>
            <tr>
                <th>Title</th>
                <th>Show Time</th>
                <th>Date</th>
                <th>Seats</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($movies->num_rows > 0): ?>
                <?php while($movie = $movies->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($movie['title']); ?></td>
                        <td><?php echo htmlspecialchars($movie['show_time']); ?></td>
                        <td><?php echo htmlspecialchars($movie['date']); ?></td>
                        <td><?php echo htmlspecialchars($movie['available_seats']); ?></td>
                        <td>
                            <a href="admin_panel.php?delete=<?php echo $movie['id']; ?>" 
                               class="delete-btn" 
                               onclick="return confirm('Are you sure you want to delete this movie? 🗑️');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5">😢 No movies available</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="back-btn-container">
        <a href="index.html" class="back-btn">⬅️ Back to Booking</a>
    </div>
</div>

</body>
</html>