﻿<?php
session_start();
include 'db.php'; 

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = isset($_POST['username']) ? trim($_POST['username']) : "";
    $password = isset($_POST['password']) ? trim($_POST['password']) : "";

    if (empty($username) || empty($password)) {
        $message = '<div class="message error">⚠ Please fill in both fields!</div>';
    } else {
        $sql = "SELECT id, username, password FROM users WHERE username = ?";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows == 1) {
                $stmt->bind_result($id, $db_username, $db_password);
                $stmt->fetch();

                if (password_verify($password, $db_password) || $password === $db_password) {
                    $_SESSION['username'] = $db_username;
                    $_SESSION['id'] = $id;
                    header("Location: movies.php");
                    exit;
                } else {
                    $message = '<div class="message error">❌ Invalid password</div>';
                }
            } else {
                $message = '<div class="message error">❌ Invalid username</div>';
            }
            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🎬 Login - Movie Booking</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap');

        :root {
            --primary-color: #6a1b9a;  /* Deep Purple */
            --secondary-color: #9575cd; /* Light Purple */
            --background-gradient: linear-gradient(135deg, #b39ddb, #d1c4e9);
            --card-bg: #fff;
            --text-color: #333;
            --success-color: #4caf50;
            --error-color: #c62828;
            --link-color: #7e57c2;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: var(--background-gradient);
            color: var(--text-color);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            background-color: var(--card-bg);
            padding: 40px;
            border-radius: 14px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.25);
            max-width: 450px;
            width: 100%;
            text-align: center;
            box-sizing: border-box;
        }

        h2 {
            color: var(--primary-color);
            margin-bottom: 25px;
            font-size: 2.2em;
            font-weight: 600;
        }
        
        form div {
            margin-bottom: 20px;
            text-align: left;
        }

        label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: #555;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-sizing: border-box;
            font-size: 1em;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            border-color: var(--secondary-color);
            outline: none;
        }

        button {
            background-color: var(--secondary-color);
            color: white;
            padding: 14px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1.1em;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            width: 100%;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        button:hover {
            background-color: #7e57c2;
            transform: translateY(-2px);
        }

        .message {
            padding: 12px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-weight: bold;
            text-align: center;
        }

        .success {
            background-color: #e8f5e9;
            color: var(--success-color);
            border: 1px solid var(--success-color);
        }

        .error {
            background-color: #f3e5f5;
            color: var(--error-color);
            border: 1px solid var(--error-color);
        }

        .link {
            color: var(--link-color);
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s ease;
        }

        .link:hover {
            color: var(--primary-color);
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>🔑 Login</h2>
    <?php echo $message; ?>
    <form method="POST" action="">
        <div>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
        </div>
        <div>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <p>🆕 Don’t have an account? <a class="link" href="register.php">Register</a></p>
        </div>
        <button type="submit">Login</button>
    </form>
</div>

</body>
</html>
