﻿<?php
session_start();
include 'db.php';

if (!isset($_SESSION['id'])) header("Location: login.php");
if (!isset($_GET['id'])) die("❌ No booking selected!");

$bookingId = intval($_GET['id']);

$stmt = $conn->prepare("SELECT b.id, b.seats, b.amount_paid, b.paid, m.title AS movie_name, m.date, m.show_time
                        FROM bookings b
                        JOIN movies m ON b.movie_id = m.id
                        WHERE b.id=? AND b.user_id=?");
$stmt->bind_param("ii", $bookingId, $_SESSION['id']);
$stmt->execute();
$result = $stmt->get_result();
$booking = $result->fetch_assoc();
$stmt->close();

if (!$booking) die("❌ Booking not found!");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Payment Page</title>
<style>
body { font-family: Arial; background:#f2f2f2; display:flex; justify-content:center; align-items:center; min-height:100vh; }
.card { width:380px; margin:40px auto; background:#fff; padding:20px; border-radius:10px; box-shadow:0 4px 12px rgba(0,0,0,0.1); }
.card h2 { text-align:center; margin-bottom:20px; }
.details { display: table; margin:0 auto 20px auto; text-align:left; }
.details p { display: table-row; margin:6px 0; font-size:15px; }
.details p strong, .details p span { display: table-cell; padding:4px 10px; }
.btn { display:inline-block; background:#007bff; color:white; padding:10px 15px; border:none; border-radius:8px; cursor:pointer; text-decoration:none; text-align:center; }
.btn:hover { background:#0056b3; }
#upiCard { display:none; margin-top:20px; padding:15px; border:1px solid #ccc; border-radius:12px; background:#fafafa; }
#upiCard input[type="number"], #upiCard input[type="password"] { width:90%; padding:8px; margin:8px 0; border:1px solid #ccc; border-radius:6px; }
.center { text-align:center; margin-top:20px; }
</style>
</head>
<body>
<div class="card">
<h2>Payment for Booking</h2>
<div class="details">
<p><strong>Movie</strong><span>: <?= htmlspecialchars($booking['movie_name']); ?></span></p>
<p><strong>Date</strong><span>: <?= htmlspecialchars($booking['date']); ?></span></p>
<p><strong>Time</strong><span>: <?= htmlspecialchars($booking['show_time']); ?></span></p>
<p><strong>Seats</strong><span>: <?= htmlspecialchars($booking['seats']); ?></span></p>
<p><strong>Total Amount</strong><span>: ₹<?= htmlspecialchars($booking['amount_paid']); ?></span></p>
<p><strong>Status</strong>
<span>: <?= $booking['paid'] ? "Paid ✅" : "Pending ⏳"; ?></span></p>
</div>

<div class="center">
    <button class="btn" onclick="showUPIForm()">Pay Using UPI</button>
</div>

<div id="upiCard" class="center">
<form action="verify.php" method="POST">
<input type="hidden" name="booking_id" value="<?= $bookingId; ?>">
<label>Enter Amount to Pay:</label><br>
<input type="number" name="amount" min="1" value="<?= $booking['amount_paid']; ?>" required><br>
<label>Enter Your UPI PIN:</label><br>
<input type="password" name="upi_pin" maxlength="6" pattern="\d{6}" required><br>
<button type="submit" class="btn">Pay Now</button>
</form>
</div>

<div class="center">
    <a href="movies.php" class="btn">Back to Booking</a>
</div>

</div>

<script>
function showUPIForm() { document.getElementById("upiCard").style.display = "block"; }
</script>
</body>
</html>
