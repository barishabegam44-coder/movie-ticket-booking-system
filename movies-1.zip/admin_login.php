﻿<?php
session_start();

// Default credentials
$admin_username = "admin";
$admin_password = "admin123"; // You can hash this in future

$message = "";

// Check if form submitted
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $input_admin = isset($_POST['admin']) ? trim($_POST['admin']) : '';
    $input_pass  = isset($_POST['pass']) ? trim($_POST['pass']) : '';

    if ($input_admin === $admin_username && $input_pass === $admin_password) {
        $_SESSION['admin'] = true;
        header("Location: admin_panel.php");
        exit();
    } else {
        $message = '<p class="error">❌ Invalid Admin credentials</p>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🔑 Admin Login</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap');

        :root {
            --primary-color: #6a1b9a;  /* Deep Purple */
            --secondary-color: #9575cd; /* Light Purple */
            --background-gradient: linear-gradient(135deg, #b39ddb, #d1c4e9);
            --card-bg: #fff;
            --text-color: #333;
            --error-color: #c62828;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: var(--background-gradient);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            background-color: var(--card-bg);
            padding: 40px;
            border-radius: 14px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.25);
            max-width: 450px;
            width: 100%;
            text-align: center;
            box-sizing: border-box;
        }

        h2 {
            color: var(--primary-color);
            margin-bottom: 25px;
            font-size: 2.2em;
            font-weight: 600;
        }

        form div {
            margin-bottom: 20px;
            text-align: left;
        }

        label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: #555;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 1em;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            border-color: var(--secondary-color);
            outline: none;
        }

        button {
            background-color: var(--secondary-color);
            color: white;
            padding: 14px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1.1em;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            width: 100%;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        button:hover {
            background-color: #7e57c2;
            transform: translateY(-2px);
        }

        .error {
            background-color: #f3e5f5;
            color: var(--error-color);
            border: 1px solid var(--error-color);
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .link {
            color: var(--secondary-color);
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s ease;
        }
        .link:hover {
            color: var(--primary-color);
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>🔑 Admin Login</h2>
    <?php echo $message; ?>
    <form method="post">
        <div>
            <label for="admin">Admin Username:</label>
            <input type="text" id="admin" name="admin" required>
        </div>
        <div>
            <label for="pass">Password:</label>
            <input type="password" id="pass" name="pass" required>
        </div>
        <button type="submit">Login</button>
    </form>
</div>

</body>
</html>
