﻿<?php
session_start();
include 'db.php';
require_once __DIR__ . '/phpqrcode/qrlib.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_POST['movie_id'], $_POST['seats']) || empty($_POST['seats'])) {
    die("❌ No seats selected. Go back and select seats.");
}

$user_id = $_SESSION['id'];
$movie_id = (int)$_POST['movie_id'];
$seats = $_POST['seats'];
$seatList = implode(",", $seats);

// Check booked seats
$bookedSeats = [];
$result = $conn->query("SELECT seats FROM bookings WHERE movie_id = $movie_id");
while ($row = $result->fetch_assoc()) {
    $bookedSeats = array_merge($bookedSeats, explode(",", $row['seats']));
}
$conflict = array_intersect($seats, $bookedSeats);
if (!empty($conflict)) {
    die("❌ Seat(s) already booked: " . implode(", ", $conflict) . "<br><a href='movies.php'>Go Back</a>");
}

// Fetch movie details
$movie = $conn->query("SELECT * FROM movies WHERE id = $movie_id")->fetch_assoc();
if (!$movie) die("❌ Movie not found.");

// Price
$price_per_seat = 100;
$seatsBooked = count($seats);
$amount_rupees = $price_per_seat * $seatsBooked;

// Insert booking
$stmt = $conn->prepare("INSERT INTO bookings (user_id, movie_id, seats, booked_at, amount_paid, paid) VALUES (?, ?, ?, NOW(), ?, 'Pending')");
$stmt->bind_param("iisi", $user_id, $movie_id, $seatList, $amount_rupees);
$stmt->execute();
$bookingId = $stmt->insert_id;

// Update available seats
$stmt2 = $conn->prepare("UPDATE movies SET available_seats = available_seats - ? WHERE id = ?");
$stmt2->bind_param("ii", $seatsBooked, $movie_id);
$stmt2->execute();

// Generate QR code
$ticketInfo = "🎟️ Ticket\nMovie: {$movie['title']}\nDate: {$movie['date']}\nTime: {$movie['show_time']}\nSeats: $seatList\nUser: {$_SESSION['username']}";
$qrDir = __DIR__ . "/qrcodes";
if (!file_exists($qrDir)) mkdir($qrDir, 0755, true);
$qrFile = $qrDir . "/booking_" . $bookingId . ".png";
QRcode::png($ticketInfo, $qrFile, QR_ECLEVEL_H, 5);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Booking</title>
<style>
.ticket { background:#fff; padding:20px; display:inline-block; border-radius:10px; box-shadow:0 5px 15px rgba(0,0,0,0.2); }
.ticket img { width:150px; margin-top:15px; }
button { padding:10px 20px; background:#00796b; color:#fff; border:none; border-radius:5px; cursor:pointer; margin-top:15px; }
button:hover { background:#004d40; }
</style>
</head>
<body>

<h2>✅ Booking Successful! Scan QR or Pay via UPI</h2>

<div class="ticket">
    <p><strong>Movie:</strong> <?= htmlspecialchars($movie['title']) ?></p>
    <p><strong>Date:</strong> <?= htmlspecialchars($movie['date']) ?></p>
    <p><strong>Time:</strong> <?= htmlspecialchars($movie['show_time']) ?></p>
    <p><strong>Seats:</strong> <?= htmlspecialchars($seatList) ?></p>
    <p><strong>User:</strong> <?= htmlspecialchars($_SESSION['username']) ?></p>
    <img src="<?= 'qrcodes/booking_' . $bookingId . '.png' ?>" alt="QR Code">
</div>

<button id="upiPayBtn">💳 Pay ₹<?= $amount_rupees ?> via UPI</button>
<div id="paymentStatus" style="margin-top:15px;"></div>

<script>
document.getElementById("upiPayBtn").addEventListener("click", function(){
    const bookingId = <?= $bookingId ?>;
    const upiPin = prompt("Enter your UPI PIN to verify payment:");

    if(!upiPin){ alert("UPI PIN required!"); return; }

    document.getElementById("paymentStatus").innerHTML = "⏳ Verifying Payment...";

    setTimeout(() => {
        fetch("verify.php", {
            method: "POST",
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: "booking_id=" + bookingId + "&upi_pin=" + encodeURIComponent(upiPin)
        })
        .then(res => res.text())
        .then(data => {
            document.getElementById("paymentStatus").innerHTML = data;
        });
    }, 1500);
});
</script>

</body>
</html>
