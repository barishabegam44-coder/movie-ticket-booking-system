﻿<?php
session_start();
include 'db.php';
require_once __DIR__ . '/phpqrcode/qrlib.php';

if (!isset($_SESSION['id'])) header("Location: login.php");
if (!isset($_POST['booking_id'], $_POST['amount'], $_POST['upi_pin'])) die("❌ Invalid request!");

$bookingId = intval($_POST['booking_id']);
$amount = intval($_POST['amount']);
$upiPin = trim($_POST['upi_pin']);

// Fetch user's PIN and username
$stmt = $conn->prepare("SELECT upi_pin, username FROM users WHERE id=?");
$stmt->bind_param("i", $_SESSION['id']);
$stmt->execute();
$stmt->bind_result($storedPin, $username);
$stmt->fetch();
$stmt->close();

if (!$storedPin) die("❌ UPI PIN not set!");
if ($upiPin !== $storedPin) header("Location: payment.php?id=$bookingId&error=1");

// Mark booking as Success
$stmt2 = $conn->prepare("UPDATE bookings SET paid='Success', amount_paid=? WHERE id=?");
$stmt2->bind_param("ii", $amount, $bookingId);
$stmt2->execute();
$stmt2->close();

// Insert into payments table
$paymentId = uniqid("PAY"); // unique payment id generate
$status = "Success";
$stmt4 = $conn->prepare("INSERT INTO payments (booking_id, payment_id, amount, status, created_at) VALUES (?, ?, ?, ?, NOW())");
$stmt4->bind_param("isis", $bookingId, $paymentId, $amount, $status);
$stmt4->execute();
$stmt4->close();

// Fetch booking + movie details
$sql = "SELECT b.id, b.seats, m.title, m.date, m.show_time 
        FROM bookings b 
        JOIN movies m ON b.movie_id = m.id 
        WHERE b.id=?";
$stmt3 = $conn->prepare($sql);
$stmt3->bind_param("i", $bookingId);
$stmt3->execute();
$result = $stmt3->get_result();
$ticket = $result->fetch_assoc();
$stmt3->close();

// Generate QR code
$qrDir = __DIR__ . "/qrcodes";
if (!file_exists($qrDir)) mkdir($qrDir, 0755, true);
$qrFile = $qrDir . "/ticket_" . $bookingId . ".png";
$ticketText = "Movie: {$ticket['title']}\nDate: {$ticket['date']}\nTime: {$ticket['show_time']}\nSeats: {$ticket['seats']}\nUser: {$username}\nAmount: ₹{$amount}\nPayment ID: {$paymentId}";
QRcode::png($ticketText, $qrFile, QR_ECLEVEL_H, 5);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Movie Ticket</title>
<style>
body { font-family: Arial; background:#f0f0f0; padding:40px; text-align:center; }
.ticket { width:400px; margin:auto; background:#fff; padding:20px; border-radius:10px; border:2px dashed #333; box-shadow:0 4px 12px rgba(0,0,0,0.1); }
.ticket h2 { color:green; margin-bottom:20px; }
.details { display:table; margin:0 auto; text-align:left; }
.details p { display:table-row; margin:6px 0; font-size:15px; }
.details .label { display:inline-block; width:120px; font-weight:bold; }
.details p span { display:table-cell; padding:4px 10px; }
.qr { margin-top:15px; }
.ticket-footer { font-size:12px; color:#555; margin-top:10px; }
button { margin-top:15px; padding:8px 12px; cursor:pointer; border:none; background:#007bff; color:#fff; border-radius:6px; }
button:hover { background:#0056b3; }
</style>
</head>
<body>

<div class="ticket">
<h2>✅ Payment Successful!</h2>
<div class="details">
<p><span class="label">User</span> : <?= htmlspecialchars($username); ?></p>
<p><span class="label">Movie</span> : <?= htmlspecialchars($ticket['title']); ?></p>
<p><span class="label">Date</span> : <?= htmlspecialchars($ticket['date']); ?></p>
<p><span class="label">Time</span> : <?= htmlspecialchars($ticket['show_time']); ?></p>
<p><span class="label">Seats</span> : <?= htmlspecialchars($ticket['seats']); ?></p>
<p><span class="label">Amount Paid</span> : ₹<?= htmlspecialchars($amount); ?></p>
<p><span class="label">Payment ID</span> : <?= htmlspecialchars($paymentId); ?></p>
</div>

<div class="qr">
<img src="qrcodes/ticket_<?= $bookingId; ?>.png" alt="Ticket QR">
</div>

<div class="ticket-footer">
🎟️ Present this ticket at the theater entrance.
</div>

<button onclick="window.print()">🖨️ Print / Save Ticket</button>
<div style="margin-top:15px;">
    <a href="movies.php"><button>⬅ Back to Booking</button></a>
</div>
</div>

</body>
</html>
