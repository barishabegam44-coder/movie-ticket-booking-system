﻿<?php
// Include database connection
include 'db.php'; 

$message = ''; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Get values safely (PHP 5.6 style)
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
 $upi_pin  = isset($_POST['upi_pin']) ? trim($_POST['upi_pin']) : '';

    if (empty($username) || empty($password)) {
        $message = '<p style="color:red;">Please fill in all fields!</p>';
    } else {
        // Insert into users table
        $sql = "INSERT INTO users (username, password,upi_pin) VALUES ('$username', '$password', '$upi_pin')";

        if ($conn->query($sql) === TRUE) {
            $message = '<p style="color:green;">✅ Registration successful!</p>';
        } else {
            $message = '<p style="color:red;">❌ Error: ' . $conn->error . '</p>';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🎬 Register - Movie Booking</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap');

        :root {
            --primary-color: #7e57c2; /* Light Purple */
            --secondary-color: #ab47bc; /* Medium Purple */
            --background-gradient: linear-gradient(135deg, #b39ddb, #9575cd, #7e57c2);
            --card-bg: #fff;
            --text-color: #333;
            --success-color: #4caf50;
            --error-color: #e53935;
            --link-color: #6a1b9a;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: var(--background-gradient);
            color: var(--text-color);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            background-color: var(--card-bg);
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
            max-width: 450px;
            width: 100%;
            text-align: center;
            box-sizing: border-box;
        }

        h2 {
            color: var(--primary-color);
            margin-bottom: 25px;
            font-size: 2.2em;
            font-weight: 600;
        }
        
        form div {
            margin-bottom: 20px;
            text-align: left;
        }

        label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: #555;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-sizing: border-box;
            font-size: 1em;
            transition: border-color 0.3s ease;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            border-color: var(--primary-color);
            outline: none;
        }

        button {
            background-color: var(--secondary-color);
            color: white;
            padding: 14px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1.1em;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            width: 100%;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        button:hover {
            background-color: #8e24aa;
            transform: translateY(-2px);
        }

        .message {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-weight: bold;
            text-align: center;
        }

        .success {
            background-color: #e8f5e9;
            color: var(--success-color);
            border: 1px solid var(--success-color);
        }

        .error {
            background-color: #ffebee;
            color: var(--error-color);
            border: 1px solid var(--error-color);
        }

        .link {
            color: var(--link-color);
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s ease;
        }

        .link:hover {
            color: #4a148c;
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>✨ Register ✨</h2>
    <?php echo $message; ?>
    <form method="POST">
        <div>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
        </div>
        <div>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
<label for="upi_pin">UPI Pin</label>
<input type="password" name="upi_pin" placeholder="Create your UPI PIN" maxlength="6" required>
            <p>✅ Already have an account? <a href="login.php" class="link">Login</a></p>
        </div>
        <button type="submit">Sign Up</button>
    </form>
</div>

</body>
</html>
