﻿<?php
session_start();
include 'db.php';

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

// Track current user pending seats
$currentUserPendingSeats = [];

// Handle seat selection form
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['movie_id'], $_POST['seats'])) {
    $movie_id = intval($_POST['movie_id']);
    $currentUserPendingSeats = $_POST['seats'];
    $seats = implode(",", $_POST['seats']);
    $user_id = $_SESSION['id'];
    $seatCount = count($_POST['seats']);
    $amount = $seatCount * 150;

    $stmt = $conn->prepare("INSERT INTO bookings (user_id, movie_id, seats, amount_paid, paid) VALUES (?, ?, ?, ?, 'Pending')");
    $stmt->bind_param("iisi", $user_id, $movie_id, $seats, $amount);
    $stmt->execute();
    $bookingId = $stmt->insert_id;
    $stmt->close();

    header("Location: payment.php?id=" . $bookingId);
    exit();
}

// Fetch movies
$movies = $conn->query("SELECT * FROM movies");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Available Movies</title>
<style>
body { margin:0; padding:30px 20px; font-family:'Segoe UI',sans-serif; background:linear-gradient(135deg,#b39ddb,#9575cd,#7e57c2); color:#000; }
.header { display:flex; justify-content:space-between; align-items:center; margin-bottom:30px; }
h2 { text-align:center; margin-bottom:10px; flex:1; }
.logout-btn { background:linear-gradient(135deg,#ff1744,#d50000); color:#fff; border:none; padding:10px 18px; border-radius:8px; cursor:pointer; font-weight:bold; }
.logout-btn:hover { background:linear-gradient(135deg,#d50000,#b71c1c); }
.movie-grid { display:flex; flex-wrap:wrap; gap:20px; justify-content:center; }
.card { background:rgba(255,255,255,0.9); border-radius:12px; padding:20px; width:320px; box-shadow:0 8px 16px rgba(0,0,0,0.3); }
.seat-map { display:grid; grid-template-columns:repeat(8,1fr); gap:6px; margin:10px 0; }
.seat { width:30px; height:30px; background:#cfd8dc; border-radius:6px; text-align:center; line-height:30px; cursor:pointer; font-size:0.8em; user-select:none; }
.seat input { display:none; }
.seat.selected { background:#8e24aa; color:#fff; } /* Pending by current user */
.seat.booked { background:#b71c1c; color:#fff; cursor:not-allowed; position:relative; } /* Success */
.card button { background:#ab47bc; color:white; border:none; padding:8px 14px; border-radius:6px; cursor:pointer; width:100%; }
.card button:hover { background:#8e24aa; }
</style>
</head>
<body>

<div class="header">
    <h2>🎬 Available Movies</h2>
    <form method="post" action="logout.php" style="margin:0;">
        <button type="submit" class="logout-btn">🚪 Logout</button>
    </form>
</div>

<div class="movie-grid">
<?php while ($movie = $movies->fetch_assoc()): ?>
    <?php
        $bookedSeats = [];
        $result = $conn->query("SELECT seats FROM bookings WHERE movie_id=" . (int)$movie['id'] . " AND paid='Success'");
        while ($row = $result->fetch_assoc()) {
            $bookedSeats = array_merge($bookedSeats, explode(",", $row['seats']));
        }
    ?>
    <div class="card">
        <h3><?= htmlspecialchars($movie['title']) ?></h3>
        <p><strong>Date:</strong> <?= htmlspecialchars($movie['date']) ?></p>
        <p><strong>Time:</strong> <?= htmlspecialchars($movie['show_time']) ?></p>

        <form method="post" action="movies.php">
            <input type="hidden" name="movie_id" value="<?= $movie['id'] ?>">
            <div class="seat-map">
                <?php
                $rows = ['A','B','C','D','E'];
                $cols = 8;
                foreach ($rows as $r) {
                    for ($c=1; $c <= $cols; $c++) {
                        $seatNo = $r.$c;
                        $isBooked = in_array($seatNo, $bookedSeats);
                        $isSelected = in_array($seatNo, $currentUserPendingSeats);
                        $class = $isBooked ? 'booked' : ($isSelected ? 'selected' : '');
                        echo '<label class="seat '.$class.'">';
                        if (!$isBooked) echo '<input type="checkbox" name="seats[]" value="'.$seatNo.'" '.($isSelected?'checked':'').'>'.$seatNo;
                        else echo $seatNo;
                        echo '</label>';
                    }
                }
                ?>
            </div>
            <br>
            <button type="submit">💳 Pay & Book</button>
        </form>
    </div>
<?php endwhile; ?>
</div>

<script>
document.querySelectorAll('.seat').forEach(seat => {
    seat.addEventListener('click', function() {
        if (this.classList.contains('booked')) return;
        const checkbox = this.querySelector('input');
        if (!checkbox) return;
        checkbox.checked = !checkbox.checked;
        this.classList.toggle('selected', checkbox.checked);
    });
});
</script>

</body>
</html>
