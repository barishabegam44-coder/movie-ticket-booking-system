﻿<?php
include 'db.php';
session_start();

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['id'];
$message = "";

// Handle booking cancellation (only Pending payments)
if (isset($_GET['cancel'])) {
    $booking_id = (int)$_GET['cancel'];

    $booking = $conn->query("SELECT * FROM bookings WHERE id = $booking_id AND user_id = $user_id")->fetch_assoc();
    if ($booking) {
        if ($booking['paid'] === 'Pending') {
            $movie_id = $booking['movie_id'];
            $seats = explode(',', $booking['seats']);
            $seatCount = count($seats);

            if ($conn->query("DELETE FROM bookings WHERE id = $booking_id")) {
                $conn->query("UPDATE movies SET available_seats = available_seats + $seatCount WHERE id = $movie_id");
                $message = "🎟️ Booking Cancelled Successfully!";
            } else {
                $message = "❌ Failed to cancel booking. Please try again!";
            }
        } else {
            $message = "⚠️ Only pending bookings can be cancelled.";
        }
    }
}

// Fetch user booking history
$bookings = $conn->query("SELECT b.id, b.seats, b.paid, m.title, m.date, m.show_time
                          FROM bookings b
                          JOIN movies m ON b.movie_id = m.id
                          WHERE b.user_id = $user_id
                          ORDER BY m.date DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Your Booking History</title>
<style>
body {
    margin: 0;
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(to right, #f0f4c3, #c8e6c9);
    color: #000;
    padding: 40px 20px;
    text-align: center;
}
h2 { margin-bottom: 20px; color: #2e7d32; }
.message {
    background-color: #aed581;
    padding: 10px 20px;
    margin-bottom: 20px;
    border-radius: 8px;
    display: inline-block;
    color: #000;
}
.booking-card {
    background: #ffffffcc;
    margin: 20px auto;
    max-width: 700px;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 0 15px rgba(0,0,0,0.3);
    text-align: left;
}
.booking-card h3 { margin: 0 0 10px 0; color: #1b5e20; }
.booking-info { margin-bottom: 10px; font-size: 1em; }
.status {
    font-weight: bold;
    padding: 4px 8px;
    border-radius: 6px;
    display: inline-block;
    color: #fff;
    margin-top: 5px;
}
.status.Pending { background: #fbc02d; }
.status.Paid { background: #388e3c; }
.status.Failed { background: #d32f2f; }

.seat-map {
    display: grid;
    grid-template-columns: repeat(8, 1fr);
    gap: 6px;
    margin: 10px 0;
}
.seat {
    width: 30px; height: 30px;
    background: #cfd8dc;
    border-radius: 6px;
    text-align: center;
    line-height: 30px;
    font-size: 0.8em;
    color: #000;
}
.seat.booked { background: #ffd54f; font-weight: bold; color: #000; }

.qr {
    width: 80px;
    height: 80px;
    border-radius: 8px;
    background: #fff;
    padding: 5px;
    display: block;
    margin-top: 10px;
}
.cancel-btn {
    display: inline-block;
    margin-top: 10px;
    color: #d32f2f;
    font-weight: bold;
    text-decoration: none;
}
.cancel-btn:hover { text-decoration: underline; }
.back-btn {
    margin-top: 30px;
    padding: 10px 20px;
    background: #1976d2;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    text-decoration: none;
}
.back-btn:hover { background: #42a5f5; }
</style>
</head>
<body>
<h2>🎬 Your Booking History</h2>

<?php if ($message): ?>
    <div class="message"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<?php if ($bookings->num_rows > 0): ?>
    <?php while ($row = $bookings->fetch_assoc()): ?>
        <?php 
            $bookedSeats = explode(',', $row['seats']);
            $rows = ['A','B','C','D','E'];
            $cols = 8;
            $qrPath = "qrcodes/booking_" . $row['id'] . ".png"; 
        ?>
        <div class="booking-card">
            <h3><?= htmlspecialchars($row['title']) ?></h3>
            <div class="booking-info"><strong>Date & Time:</strong> <?= htmlspecialchars($row['date'].' '.$row['show_time']) ?></div>
            <div class="booking-info"><strong>Status:</strong> <span class="status <?= $row['paid'] ?>"><?= $row['paid'] ?></span></div>
            <div class="seat-map">
                <?php
                foreach ($rows as $r) {
                    for ($c=1; $c <= $cols; $c++) {
                        $seatNo = $r.$c;
                        $isBooked = in_array($seatNo, $bookedSeats);
                        echo '<div class="seat '.($isBooked?'booked':'').'">'.($isBooked?$seatNo:'').'</div>';
                    }
                }
                ?>
            </div>
            <?php if ($row['paid'] === 'Paid' && file_exists($qrPath)): ?>
                <img src="<?= $qrPath ?>" alt="QR" class="qr">
            <?php elseif ($row['paid'] !== 'Paid'): ?>
                <p>❌ QR will be available after payment</p>
            <?php endif; ?>

            <?php if ($row['paid'] === 'Pending'): ?>
                <a class="cancel-btn" href="?cancel=<?= $row['id'] ?>" onclick="return confirm('Are you sure you want to cancel this booking?')">Cancel Booking</a>
            <?php endif; ?>
        </div>
    <?php endwhile; ?>
<?php else: ?>
    <p>You have no bookings yet.</p>
<?php endif; ?>

<a class="back-btn" href="movies.php">⬅️ Back to Booking</a>
</body>
</html>
