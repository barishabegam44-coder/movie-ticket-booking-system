﻿<?php
session_start();
include 'db.php';

// Get booking ID from QR code URL
if (!isset($_GET['id'])) {
    die("❌ Invalid ticket link.");
}

$booking_id = (int)$_GET['id'];

// Fetch booking info
$stmt = $conn->prepare("
    SELECT b.seats, b.booked_at, u.username, m.title, m.date, m.show_time
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    JOIN movies m ON b.movie_id = m.id
    WHERE b.id = ?
");
$stmt->bind_param("i", $booking_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("❌ Booking not found.");
}

$booking = $result->fetch_assoc();
$seats = explode(',', $booking['seats']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>🎟️ Movie Ticket</title>
<style>
body {
    margin: 0;
    padding: 40px 20px;
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(135deg, #ffcc80, #ffb74d);
    text-align: center;
}
.ticket-container {
    max-width: 450px;
    margin: 0 auto;
    background: #fff;
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
    overflow: hidden;
    border: 2px dashed #ff9800;
}
.ticket-header {
    background: linear-gradient(135deg, #ff9800, #f44336);
    color: #fff;
    padding: 15px;
    font-size: 1.3em;
    font-weight: bold;
}
.ticket-body {
    padding: 20px;
    text-align: left;
}
.ticket-body p {
    margin: 8px 0;
    font-size: 1em;
}
.seats {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
}
.seat-box {
    background: #4caf50;
    color: #fff;
    padding: 6px 10px;
    border-radius: 6px;
    font-weight: bold;
}
.qr {
    display: block;
    margin: 20px auto;
    width: 120px;
    height: 120px;
}
.ticket-footer {
    background: #ffeb3b;
    color: #000;
    padding: 10px;
    text-align: center;
    font-weight: bold;
}
</style>
</head>
<body>

<div class="ticket-container">
    <div class="ticket-header">🎬 <?= htmlspecialchars($booking['title']) ?> 🎬</div>
    <div class="ticket-body">
        <p><strong>User:</strong> <?= htmlspecialchars($booking['username']) ?></p>
        <p><strong>Date:</strong> <?= htmlspecialchars($booking['date']) ?></p>
        <p><strong>Time:</strong> <?= htmlspecialchars($booking['show_time']) ?></p>
        <p><strong>Seats:</strong></p>
        <div class="seats">
            <?php foreach($seats as $s): ?>
                <div class="seat-box"><?= htmlspecialchars($s) ?></div>
            <?php endforeach; ?>
        </div>
        <p><strong>Booked At:</strong> <?= htmlspecialchars($booking['booked_at']) ?></p>

        <!-- QR code display -->
        <?php
        $qrFile = "qrcodes/booking_" . $booking_id . ".png";
        if (file_exists($qrFile)):
        ?>
            <img src="<?= $qrFile ?>" alt="QR Code" class="qr">
        <?php endif; ?>
    </div>
    <div class="ticket-footer">🎟️ Enjoy your Movie! 🎟️</div>
</div>

</body>
</html>
